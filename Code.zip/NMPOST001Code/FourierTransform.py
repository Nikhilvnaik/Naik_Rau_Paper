import numpy as np
import matplotlib.pyplot as plt
from scipy import fftpack as fp
import os

SkyImage_1D = np.loadtxt('GBTImage.txt', delimiter = ',', comments = '#'); # Read the data as a 1D array first
Npixels = np.sqrt(SkyImage_1D.shape); #Calculate the number of pixels (It is also there in the file header.)
SkyImage = SkyImage_1D.reshape(Npixels, Npixels).T; #Convert it into a square matrix of Npixels * Npixels size.

# Get the remaining info about the power pattern, such as FOV and No. of pixels.
with open('GBTImage.txt', 'r') as f :
        header = f.readline().strip();

fov_u = float(header[6:19]); # Get the FOV in RA from header
fov_v = float(header[20:]);  # Get the FOV in DEC from header

# Plot the power pattern that you've read from the file.
plt.figure(1);
plt.imshow(SkyImage, extent = [-fov_u/2.0, +fov_u/2.0, -fov_v/2.0, fov_v/2.0]);
plt.xlabel('RA in arcmin from centre.');
plt.ylabel('DEC in arcmin from centre.');
plt.title('GBT Sky Image');
plt.colorbar(orientation = 'vertical');
plt.show();

# Take the Fourier Transform.
FFT1 = fp.fft2(SkyImage);
FFT_output = fp.fftshift(FFT1);
FFTGBTImage_Mag = np.abs(FFT_output);                      # Use the Wiener-Khinchin theorem and your brains.
FFTGBTImage_Normalised = FFTGBTImage_Mag/np.amax(FFTGBTImage_Mag); # Normalise the pattern!

# Convert to Wavelength Units  using the FOV formula.
vsweep = 0.5 * float(Npixels * (1.0/(fov_v*3.14159)) * 180.0 *60.0) ;
usweep = 0.5 * float(Npixels * (1.0/(fov_u*3.14159)) * 180.0 *60.0) ; 
#print (usweep, vsweep);
# Plot it, with the FOV converted to a uv-sweep vector. 
plt.figure(2);
plt.imshow(FFTGBTImage_Normalised, extent  = [-usweep, +usweep, -vsweep, +vsweep]);
plt.colorbar(orientation = 'vertical');
plt.xlabel('u-sweep (wavelength units)');
plt.ylabel('v-sweep (wavelength units)');
plt.title('Fourier transform of the GBT image');
plt.show();

# Now open the Interferometer image that has been saved as IntImage.
ia.open('IntImage.image');
img_data = ia.getchunk();
img_at_f1 = img_data[:,:,0,1].T;
#print(usweep);
#print(vsweep);
#plt.clf();
plt.figure(3);
plt.imshow(img_at_f1, extent = [-fov_u/2.0, +fov_u/2.0, -fov_v/2.0, fov_v/2.0]);
plt.colorbar(orientation = 'vertical');
plt.xlabel('RA in arcmin from Centre.');
plt.ylabel('DEC in arcmin from centre.');
plt.title('VLA Sky Image');
plt.show();

# Fourier-Transform the interferometer image and plot that also.
FFT1 = fp.fft2(img_at_f1);
FFT_output = fp.fftshift(FFT1);
FFTVLAImage_Mag = np.abs(FFT_output);                      # Use the Wiener-Khinchin theorem and your brains.
FFTVLAImage_Normalised = FFTVLAImage_Mag/np.amax(FFTVLAImage_Mag); # Normalise the pattern!

# Plot the Fourier Transform.
plt.figure(4);
plt.imshow(FFTVLAImage_Normalised, extent = [-usweep, +usweep, -vsweep, +vsweep]);
plt.xlabel('u-sweep in wavelength units from Centre.');
plt.ylabel('v-sweep in wavelength units from centre.');
plt.title('FFT of VLA Sky Image');
plt.colorbar(orientation = 'vertical');
plt.show();

# Write out all the stuff into files.
# Write the output pattern to a file for future programs to read.
try:
        os.system('rm -rf GBTImageFT.txt');
	os.system('rm -rf VLAImageFT.txt');
except:
        print('GBT Image Fourier Transform file doesn\'t exist. Creating one...');
	print('GBT Image Fourier Transform file doesn\'t exist. Creating one...');

GBTimageFTOut = open('GBTImageFT.txt', 'a');
VLAimageFTOut = open('VLAImageFT.txt', 'a');
GBTimageFTOut.write('# ' + str(Npixels) + ' ' + str(fov_u) + ' ' + str(fov_v) +'\n');
VLAimageFTOut.write('# ' + str(Npixels) + ' ' + str(fov_u) + ' ' + str(fov_v) +'\n');
GBTimageFTOut.write('# ' + 'Npixels, FOV in RA, FOV in DEC in that order recorded above.\n');
VLAimageFTOut.write('# ' + 'Npixels, FOV in RA, FOV in DEC in that order recorded above.\n');

# The actual writing part. In case it's tha last entry, omit the comma. Do this for the VLA and GBT.
for i in range(0, FFTGBTImage_Normalised.shape[0]):
        for j in range(0, FFTGBTImage_Normalised.shape[1]):
                if(i == FFTGBTImage_Normalised.shape[0] -1 and j == FFTGBTImage_Normalised.shape[1] -1):
                        GBTimageFTOut.write(str(FFTGBTImage_Normalised[i][j]));
                else:
                        GBTimageFTOut.write(str(FFTGBTImage_Normalised[i][j]) + ',');

# Save and Close the file.
GBTimageFTOut.close();

# The actual writing part. In case it's tha last entry, omit the comma. Do this for the VLA and GBT.
for i in range(0, FFTVLAImage_Normalised.shape[0]):
        for j in range(0, FFTVLAImage_Normalised.shape[1]):
                if(i == FFTVLAImage_Normalised.shape[0] -1 and j == FFTVLAImage_Normalised.shape[1] -1):
                        VLAimageFTOut.write(str(FFTVLAImage_Normalised[i][j]));
                else:
                        VLAimageFTOut.write(str(FFTVLAImage_Normalised[i][j]) + ',');
# Save and Close the file.
VLAimageFTOut.close();


intim = 'IntImage.image'

gbtobs = 'GBTImage.image'

os.system('rm -rf '+gbtobs)
os.system('cp -r '+intim+' '+ gbtobs)

ib = iatool()
ib.open(intim)

ia.open(gbtobs)
pix = ia.getchunk()
ia.setrestoringbeam(remove=True)

for chan in range(0,3):
	rbeam = ib.restoringbeam(channel=chan, polarization=0)
	
	pix[:,:,0,chan] = SkyImage.T 
	
	rbeam['major']['value'] = 6.8
	rbeam['major']['unit'] = 'arcmin'
	rbeam['minor']['value'] = 6.8
	rbeam['minor']['unit'] = 'arcmin'

	ia.setrestoringbeam(beam=rbeam, channel=chan, polarization=0)
	

ia.putchunk(pix)

ia.close()

#####  Use  imsubimage to pull out one channel at a time.
#####  'Feather'
