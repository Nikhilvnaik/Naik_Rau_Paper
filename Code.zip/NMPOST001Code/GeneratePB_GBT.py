import numpy as np 
import matplotlib.pyplot as plt 
import scipy.fftpack as fp 
import os

lam = 0.20; # in m
N = 256;  # Npixels
usweep = 6445.0; #in wavelength units 
vsweep = 6445.0; # in wavelength units
uvgrid = np.zeros((N,N));
upoints = np.arange(-usweep, +usweep, 2*usweep/N); #define the u-grid of N points
vpoints = np.arange(-vsweep, +vsweep, 2*vsweep/N); #define the v-grid of N points
GBTdiameter = 100.0; # in meters
GBTdiameter_wavln = GBTdiameter/lam; # in wavelength units
GBTradius_wavln = GBTdiameter_wavln/2.0; # radius in wavelength units

print("Wavelength is... ", lam, "m\n");
print("GBT radius in wavelength units is...", GBTradius_wavln, "\n");

# Calculate the Beam in the uv-sample-domain. If the u,v coverage is inside the GBT dish, put 1 onto the uv-grid.
for i in upoints:
	for j in upoints:
		if((i**2+j**2) <= GBTradius_wavln**2):   # If the u,v sample points lie inside a circle, add them into the array.
			uindex = np.where(upoints == i);
			vindex = np.where(vpoints == j);
			uvgrid[uindex[0][0]][vindex[0][0]] = 1;

# Plot the intensity pattern in terms of u,v.
plt.subplot(121);
plt.imshow(uvgrid, extent = [-usweep, +usweep, -vsweep, +vsweep]);
plt.colorbar(orientation = 'vertical');
plt.xlabel('u-sweep (Wavelength Units)');
plt.ylabel('v-sweep (Wavelength Units)');
plt.title('Receiver Sensitivity of the GBT in units of Wavelength');
#plt.show();

##################################################################################################################
# Now do the Fourier Transform and generate the Antenna Power Pattern.                                           #
# For some reason, there are 2 FFTs needed to set things right. Refer to the                                     # 
# link www.astrobetter.com/blog/2010/03/03/fourier-transforms-of-images-in-python for more on the "How and Why". #
##################################################################################################################

FFT1 = fp.fft2(uvgrid);
FFT_output = fp.fftshift(FFT1);
AntennaPattern2D = np.abs(FFT_output)**2;                      # Use the Wiener-Khinchin theorem and your brains.
AntennaPattern2D = AntennaPattern2D/np.amax(AntennaPattern2D); # Normalise the pattern!


# Calculate the angular scales now. 
ucellsize = upoints[1] - upoints[0];
vcellsize = vpoints[1] - vpoints[0];
fov_u = (1.0/ucellsize) * (180.0/3.14159) * 60; #FOV in u-direction, arcmin
fov_v = (1.0/vcellsize) * (180.0/3.14159) * 60; #FOV in v-direction, arcmin
# print(fov_v*60/N, fov_u*60/N) Calculate the angular cell size in arcsec to make sure.

# Plot the Primary beam of the antenna now.
plt.subplot(122);
plt.imshow(AntennaPattern2D, extent = [-fov_u/2.0, +fov_u/2.0, -fov_v/2.0, +fov_v/2.0]);
#plt.colorbar(orientation = 'vertical');
plt.xlabel('RA (From a fixed centre), arcmin');
plt.ylabel('DEC (From a fixed centre), arcmin');
plt.title('Plot of the Antenna Power Pattern with the sky angle');
plt.show();

# Write the thing to a file so that it can be read later.
try:
	os.system('rm -rf GBTpowerpattern.txt');
except:
	print('GBT power pattern file doesn\'t exist. Creating one...');

PowerPatternOut = open('GBTpowerpattern.txt', 'a');
PowerPatternOut.write('# ' + str(N) + ' ' + str(fov_u) + ' ' + str(fov_v) +'\n');
PowerPatternOut.write('# ' + 'Npixels, FOV in RA, FOV in DEC in that order recorded above.\n');

# The actual writing part. In case it's tha last entry, omit the comma.
for i in range(0, AntennaPattern2D.shape[0]):
	for j in range(0, AntennaPattern2D.shape[1]):
		if(i == AntennaPattern2D.shape[0] -1 and j == AntennaPattern2D.shape[1] -1):
			PowerPatternOut.write(str(AntennaPattern2D[i][j]));	
		else:
			PowerPatternOut.write(str(AntennaPattern2D[i][j]) + ',');	

# Save and Close the file.
PowerPatternOut.close();



