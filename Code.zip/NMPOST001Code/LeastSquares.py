import numpy as np
import matplotlib.pyplot as plt
import random
import os

# You can adjust the degree of the polynomial to be fitted.
degree = 2;

# Initialise everything.
xarray = np.arange(0, 10, 0.1);
y_pure = 3.1415*(xarray**3) + 2.4142*(xarray**2) + 10.75205 * xarray + 2.232;
errors = np.random.randint(0,1000, 100);
yarray = y_pure + errors/40.0;
	
plt.clf();
# Plot a basic dataset.
def plot(xaxis, yaxis, line):
	#plt.clf();
	if(line):
		plt.plot(xaxis, yaxis);
	else:
		plt.plot(xaxis, yaxis, '.');	
	plt.show();

# Writing the matrix - calculate the coeffs in the hessian matrix.
def populateHessian(xarray, yarray):
	n = len(xarray); # number of points.
	pivot = xarray[n/2];
	xprimearray = xarray - pivot;
	hessian_coeffarray = np.zeros(2*degree+1);
	for i in range(0, (2*degree+1)):
		coeff_deg_i = 0.0;
		for j in range(0, n):
			coeff_deg_i += xarray[j]**i;
		hessian_coeffarray[i] = coeff_deg_i;
	#print hessian_coeffarray;
	return hessian_coeffarray;

# Compute the matrix of weights.
def calculate_weights(xarray, yarray):
	weightmatrix = np.zeros(degree+1);
	for i in range(0,degree+1):
		weight_ith_entry = 0.0;
		for j in range(0, len(xarray)):
			 weight_ith_entry += yarray[j]*(xarray[j]**i);
		weightmatrix[i] = weight_ith_entry;
	#print weightmatrix, "\n";
	return weightmatrix;

# Make the complete hessian matrix and calculate the coefficients.
def MakeHessian(hessian_coeffarray, weightmatrix):
	degree = (len(hessian_coeffarray) - 1)/2;
	hessian = np.zeros((degree+1, degree+1));
	for i in range(0,degree+1):
		for j in range(0, degree+1):
			hessian[i][j] = hessian_coeffarray[i+j];
	#print hessian, "\n";
	return hessian;

#Calculate and return the coefficients
def SolveEqn(hessian, weightmatrix):
	inverse_of_hessian = np.linalg.inv(hessian);
	weightmatrix = weightmatrix.T;
	coeffarray = np.matmul(inverse_of_hessian, weightmatrix);
	#print coeffarray;
	return coeffarray;

# Calculate the output value. 
def calculateOutput(xarray, coeff):
	outarray = np.zeros(len(xarray));
	for i in range(0, len(coeff)):
		outarray += coeff[i]*(xarray**i);
	return outarray;

plot(xarray, yarray, line = False);
hessian_coeffarray = populateHessian(xarray, yarray);
weights = calculate_weights(xarray, yarray);
hessian = MakeHessian(hessian_coeffarray, weights);
coeff = SolveEqn(hessian, weights);
coeff_using_routine = np.polyfit(xarray, yarray, degree);
print coeff, "My method\n numpy routine", coeff_using_routine;
y_out = calculateOutput(xarray, coeff);
plot(xarray, y_out, line = True);

