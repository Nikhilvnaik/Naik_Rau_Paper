import numpy as np
import matplotlib.pyplot as plt
import os
import sys

def TaylortoCube(freqlist, nterms, imagename = ''):
	ia.open(imagename + '.tt0');
	pixdata_table = ia.getchunk()[:,:,0,0];
	ia.close();
	cube_layer = np.zeros(pixdata_table.shape);	# Make the 1st layer of the cube that will hold the image.
	cube = cube_layer; 				# Initialise the data structures for both output and taylor image cube.
	cube_taylorimages = cube_layer;
	for i in range(0, len(freqlist) - 1): 		# Make as many images as there are frequencies.
		cube = np.dstack((cube, cube_layer));
	for i in range(0, nterms - 1):			# Make as many planes in this data structure as there are taylor terms.
		cube_taylorimages = np.dstack((cube_layer, cube_taylorimages));
	for i in range(0, nterms):
		ia.open(imagename + '.tt' + str(i))
		cube_taylorimages[:,:,i] = ia.getchunk()[:,:,0,0];
		ia.close();
		for freq in freqlist:
			scalefactor = ((freq - 1.5)/1.5)**i;
			index = freqlist.index(freq);
			cube[:,:,index] += cube_taylorimages[:,:,i] * scalefactor;
	for i in range(0,3):
		plt.imshow(cube[:,:,i]);
		plt.colorbar(orientation = 'vertical');
		raw_input("Press return");
	return cube;
			
def write_to_casaimage_2(data, imagename = '', extension = ''):
        numpsfs = data.shape[2]; # get the total number of psfs.
        ia.open(imagename + extension);
	pixdata = ia.getchunk();
        for i in range(0, numpsfs):
		pixdata[:,:,0,i] = data[:,:,i];
	ia.putchunk(pixdata);	
        ia.close();

#imagecube = TaylortoCube([1.0, 1.5, 2.0], 2 , 'multifreqpsf.image');
#write_to_casaimage(imagecube, imagename = 'Recreated_Cube', extension = '.image');
