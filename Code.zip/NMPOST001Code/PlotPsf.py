import matplotlib.pyplot as plt
import numpy as np
import scipy.fftpack as fp
import os

# function to fourier-transform stuff.
def fourier_transform(input):
	FFT_stage1 = fp.fft2(input);
	FFT_final = fp.fftshift(FFT_stage1);
	FFT_final = np.abs(FFT_final);
	return FFT_final;

# initialise - close all open images if any and open the relevant ones. Get the relevant data blocks.
ia.close();
ia.open('Image_IFMcomposite.psf');
pixels = ia.getchunk();
ia.close();
ib = iatool();
ib.open('master_images/try1.psf');
ia.setrestoringbeam(remove = True);
pixels_pureifm = ib.getchunk();
ib.close();
ic = iatool();
ic.open('Image_SID.psf');
#ic.setrestoringbeam(remove = False);
pixels_SID = ic.getchunk();
ic.close();

# Fourier transform it frequency-by-frequency and plot.
for i in range(0,3):
	pixels_composite_freq_i = pixels[:,:,0,i];
	pixels_pure_freq_i = pixels_pureifm[:,:,0,i];
	pixels_sid_freq_i = pixels_SID[:,:,0,i];
	uv_coverage_composite = fourier_transform(pixels_composite_freq_i);
	uv_coverage_pure = fourier_transform(pixels_pure_freq_i);
	uv_coverage_sid = fourier_transform(pixels_sid_freq_i);
	plt.figure(1);
	plt.imshow(uv_coverage_composite);
	plt.xlabel("u-sweep in arbitrary units");
	plt.ylabel("v-sweep in arbitrary units");
	plt.title("Plot of uv-sweep for composite PSF");
	plt.figure(2);
	plt.imshow(uv_coverage_sid);
	plt.xlabel("u-sweep in arbitrary units");
	plt.ylabel("v-sweep in arbitrary units");
	plt.title("Plot of uv-sweep for sid");
	plt.colorbar(orientation = 'vertical')
	raw_input("Press Return to continue.");
	uv_cov_composite_slice = uv_coverage_composite[128,:];
	uv_cov_pure_slice = uv_coverage_pure[128,:];
	uv_cov_sid_slice  = uv_coverage_sid[128,:];
	index = np.arange(len(uv_coverage_pure));
	plt.subplot(121)
	plt.plot(index, uv_cov_composite_slice);
	plt.title('Composite uv-coverage slice')
	plt.subplot(122)
	plt.plot(index, uv_cov_pure_slice);
	plt.title('Pure uv-coverage slice')
	plt.show();
	area_pure = 0.0;
	area_sid = 0.0;
	for count in index:
		area_pure += uv_cov_pure_slice[count];
		area_sid +=  uv_cov_sid_slice[count];
	print area_pure;
	print area_sid;
	raw_input("Press Return to Continue."); #Interactive, to avoid confusion between figures.

