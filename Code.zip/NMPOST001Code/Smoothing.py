imsubimage(imagename = 'mysky.true.im',outfile='chan0_mysky.true.im', chans='0')

ia.open('IntImage.image')
qq = ia.restoringbeam(channel=0)
ia.close()

ia.open('chan0_mysky.true.im')
zz = ia.convolve2d(type='gaussian',outfile='smoothed_chan0_mysky.im',major=qq['major'], minor=qq['minor'],pa=qq['positionangle'] )
zz.close()
ia.close()

imsubimage(imagename = 'mysky.true.im',outfile='chan1_mysky.true.im', chans='1')

ia.open('IntImage.image')
qq = ia.restoringbeam(channel=1)
ia.close()

ia.open('chan1_mysky.true.im')
zz = ia.convolve2d(type='gaussian',outfile='smoothed_chan1_mysky.im',major=qq['major'], minor=qq['minor'],pa=qq['positionangle'] )
zz.close()
ia.close()

imsubimage(imagename = 'mysky.true.im',outfile='chan2_mysky.true.im', chans='2')

ia.open('IntImage.image')
qq = ia.restoringbeam(channel=2)
ia.close()

ia.open('chan2_mysky.true.im')
zz = ia.convolve2d(type='gaussian',outfile='smoothed_chan2_mysky.im',major=qq['major'], minor=qq['minor'],pa=qq['positionangle'] )
zz.close()
ia.close()
