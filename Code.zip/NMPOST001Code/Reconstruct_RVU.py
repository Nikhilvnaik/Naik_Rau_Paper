## (1) Import the python application layer

from imagerhelpers.imager_base import PySynthesisImager
from imagerhelpers.input_parameters import ImagerParameters

sdgain = 3.0; # For feathering, set the single dish gain.
ia.close();
ib = iatool();

imname = 'Try'
nterms=2

def setup_cube():

    paramList = ImagerParameters(
        msname ='mysky.ms',
        datacolumn = 'corrected',
	field='',
        spw='',
        imagename=imname,
        imsize=256, 
        cell='16.0arcsec', 
        specmode='cube',
        gridder='standard',
        weighting='natural',
        niter=128,
        deconvolver='hogbom',
	nchan = -1
        )
    
    imager = PySynthesisImager(params=paramList)
    
    imager.initializeImagers()           
    imager.initializeNormalizers()
    imager.setWeighting()

    imager.makePSF()
    imager.runMajorCycle()  # Make initial dirty / residual image

#    feather_psf(imagename=imname)
#    feather_residual(imagename=imname)

#    imager.restoreImages()

    return imager

#    imager.deleteTools()


def setup_mfs():

    paramList = ImagerParameters(
        msname ='mysky.ms',
        datacolumn = 'corrected',
	field='',
        spw='',
        imagename=imname,
        imsize=256, 
        cell='16.0arcsec', 
        specmode='mfs',
        reffreq='1.5GHz',
        gridder='standard',
        weighting='natural',
        niter=128,
        deconvolver='mtmfs',
        nterms=nterms,
	nchan = -1
        )
    
    imager = PySynthesisImager(params=paramList)

    imager.initializeImagers()           
    imager.initializeNormalizers()
    imager.setWeighting()

    imager.makePSF()
    imager.runMajorCycle()  # Make initial dirty / residual image
    
    imager.initializeDeconvolvers()
    imager.initializeIterationControl()


    return imager


execfile('CreateMTPsfs.py')
execfile('TaylortoCube.py')

def do_reconstruct():

    os.system('rm -rf Try.*')

    imager_cube = setup_cube()
    imager_mfs = setup_mfs()
    
    reffreq=1.5

    sdimage = 'GBTImage.Image'

#    feathering_cube_psf(imname+.psf,  sdbeam)
#    assign_beam_info_from_psf_to_cube()
#    feather_cube_residual(imname+'.residual', sdimage)

    pix = getdata(imname , '.psf');
    psfs = CalcPSF(pix, nterms, [1.0, 1.5, 2.0]);
    write_to_casaimage_3(data=psfs, imagename = imname, extension = '.psf');

    pix = getdata(imname , '.residual');
    residuals = CalcResiduals(pix, nterms, [1.0, 1.5, 2.0]);
    write_to_casaimage_3(data=residuals, imagename = imname, extension = '.residual');


    imager_mfs.hasConverged()
    imager_mfs.updateMask()

    imager_mfs.runMinorCycle()
        
    while ( not imager_mfs.hasConverged() ):
        imager_mfs.runMinorCycle()


        imagecube = TaylortoCube([1.0, 1.5, 2.0], nterms , imagename = imname+'.model');
        os.system('cp -r '+imname+'.psf '+imname+'.model')
        write_to_casaimage_2(data=imagecube, imagename = imname, extension = '.model');

        ## Major cycle for interferometer data
        imager_cube.runMajorCycle()

        ## Major cycle for Singld Dish data
        ## subtract_model_from_GBTcube()

#         assign_beam_info_from_psf_to_cube()
##        feather_cube_residual(imname+'.residual,  sdresidual)

        pix = getdata(imname , '.residual');
        residuals = CalcResiduals(pix, nterms, [1.0, 1.5, 2.0]);
        write_to_casaimage_3(data=residuals, imagename = imname, extension = '.residual');


        imager_mfs.updateMask()

    imager_mfs.restoreImages()

    imager_cube.deleteTools()
    imager_mfs.deleteTools()



def subtract_model_from_SDcube():
    
    #(1) Smooth model cube by SD beams (per chan)
    #(2) Calculate residual SDcube :  sdresidual = sdimage - smoothed(modelcube)
    
    return


def convert_cube_to_Taylorsums(ext='psf',reffreq=1.5,imagename='',nterms=2):

    freqlist = getFreqList(imagename + '.'+ext)


def convert_Taylor_model_to_cube(reffreq=1.5,imagename='', nterms=2):

    freqlist = getFreqList(imagename + '.'+ext)

    if not os.path.exists(imagename+'.model'):
           os.system('cp -r '+imagename+'.psf '+imagename+'.model')
    
    ia.open(imagename + '.model')
    pix = ia.getchunk()
    ia.close()

    ia.open(imagename + '.' + ext + '.tt0')
    pixmfs = ia.getchunk()
    ia.close()

    nterms=2

    for tt in range(0,nterms):
        pixmfs.fill(0.0)
        for chan in range(0,len(freqlist)): 
            scalefactor = ((freqlist[chan] - 1.5)/1.5)**tt ; # calculate the exponent 
            pixmfs = pixmfs + pix[chan]* scalefactor

        ia.open(imagename + '.' + ext + '.tt'+str(tt))
        ia.putchunk(pixmfs)
        ia.close()





    
def getFreqList(imname=''):
  ia.open(imname)
  csys = ia.coordsys()
  shp = ia.shape()
  ia.close()

  if(csys.axiscoordinatetypes()[3] == 'Spectral'):
       restfreq = csys.referencevalue()['numeric'][3]/1e+09; # convert more generally..
       freqincrement = csys.increment()['numeric'][3]/1e+09;
       freqlist = [];
       for chan in range(0,shp[3]):
             freqlist.append(restfreq + chan * freqincrement);
  elif(csys.axiscoordinatetypes()[3] == 'Tabular'):
       freqlist = (csys.torecord()['tabular2']['worldvalues'])/1e+09;
  else:
       casalog.post('Unknown frequency axis. Exiting.','SEVERE');
       return False;

  return freqlist



####
#### Modify the PSF and Residual on disk by feathering in the GBT (SD) image and PB.
####
#==================================================================================================================================================
def feather_psf(imagename = 'Image_IFM'):
	os.system('rm -rf PSF_*_chan*.psf/');

	for i in range(0,3):	
#---------------------------------------------------------------------------------------------------------------------------------------------------
# Pull out channel-wise PSFs of IFM and single Dish, write them to disk. After feathering them, write out the hybrid PSF to the disk in a CASA image.
#---------------------------------------------------------------------------------------------------------------------------------------------------
		imsubimage(imagename = imagename + '.psf', outfile = 'PSF_IFM_chan' + str(i) + '.psf', chans = str(i));
		imsubimage(imagename = 'Image_SID.psf', outfile = 'PSF_SID_chan' + str(i) + '.psf', chans = str(i));
		feather(imagename = 'Feathered_psf_chan' + str(i) + '.psf', highres = 'PSF_IFM_chan' + str(i) + '.psf', lowres = 'PSF_SID_chan' + str(i) + '.psf', sdfactor = sdgain);
#------------------------------------------------------------------------------------------------------------------------------------------
    # (1) Use imsubimage to pull out each channel of SD_pb, imagename.psf
    # (2) Do the feathering (per channel) to make Feather_psf
    # (3) Copy the contents of Feather_psf (each plane) into imagename.psf
#-------------------------------------------------------------------------------------------------------------------------------------------
	write_to_casaimage(imagename = imagename, extension = '.psf');
	ia.close();	
	return;
#===========================================================================================================================================

#===========================================================================================================================================
def feather_residual(imagename=''):

 	os.system('rm -rf Image_SID_chan*.image'); # Remove all channel-wise images that were previously there.
	os.system('rm -rf Image_IFM_chan*.image'); # Both for the GBT as well as VLA images.
#------------------------------------------------------------------------------------------------------------------------------------------	
	# Restoring beam info has to be put in separately into the feather file, it isn't there. so copy the beam from PSF file.
	# Break both SD and IFM images into frequency-channel-wise subimages and feather them.
#------------------------------------------------------------------------------------------------------------------------------------------
	for i in range(0,3):
		imsubimage(imagename ='Image_SID.image', outfile = 'Image_SID_chan' + str(i) + '.image', chans = str(i));	
		imsubimage(imagename ='Image_IFM.residual', outfile = 'Image_IFM_chan' + str(i) + '.image', chans = str(i));		
	ia.open('Image_IFM.psf');
	for count in range(0,3): # This little trick had to be done to put in the beam info into the subimage. I guess mostly it's clear enough.
		beam_ifm = ia.restoringbeam(channel=count, polarization=0);
		ib.open('Image_IFM_chan' + str(count) + '.image');
		ib.setrestoringbeam(beam=beam_ifm);
		ib.close();
	ia.close();
#------------------------------------------------------------------------------------------------------------------------------------------
# Feather each one channel-by-channel and write to disk. Eventually I will remove the intermediate images and start writing only the final one.
#------------------------------------------------------------------------------------------------------------------------------------------
	for i in range(0,3):	
		feather(imagename = 'Feathered_img_chan' + str(i) + '.image', highres  = 'Image_IFM_chan' + str(i) + '.image', lowres = 'Image_SID_chan' + str(i) + '.image', sdfactor = sdgain);	
	# Now write everything into a composite image file.
	write_residual_to_casaimage(infiles = 'Feathered_img_chan', imagename= 'Image_IFM');
	return;
#===========================================================================================================================================

#===========================================================================================================================================
def write_to_casaimage(imagename = 'Image_IFM', extension = '.psf'):
	#os.system('rm -rf '+ imagename  + 'composite' +extension);
	#os.system('cp -pr Image_SID.image ' + imagename +'composite' + extension);
	ia.open(imagename + extension);
	pixeldata = ia.getchunk();
	for i in range(0,3):
		ib.open('Feathered_psf_chan' + str(i) + '.psf'); # only does the PSF as of now!!
		pixeldata_indiv_chunk = ib.getchunk(); # get chunk-wise pixel data.
		pixeldata_indiv_chan = pixeldata_indiv_chunk[:,:,0,0] # convert it into a numpy array to feed back in.
		pixeldata[:,:,0,i] = pixeldata_indiv_chan;
	ia.putchunk(pixeldata);
	ib.close();
	ia.close();
	return;
#===========================================================================================================================================
	
#===========================================================================================================================================
# Write the feathered image into the xyz.residual file.
#-------------------------------------------------------------------------------------------------------------------------------------------
def write_residual_to_casaimage(infiles = '', imagename = ''):
	ia.close(); #Close anything if it was open.
	ia.open(imagename + '.residual');
	pixel_data = ia.getchunk();
	ia.setrestoringbeam(remove = True);
	for i in range(0,3):
		ib.open(infiles + str(i) + '.image');
		beam = ib.restoringbeam(channel = 0, polarization = 0);
		pixel_data_residual = ib.getchunk(); # get the raw data from the single-channel images.
		ib.close();
		ia.setrestoringbeam(beam = beam, channel = i); # place the beam info in
		pixel_data[:,:,0,i] = pixel_data_residual[:,:,0,0];	# place the data in
	ia.putchunk(pixel_data); # put the data into the data structure.
	ia.close();	
#===========================================================================================================================================

## You will need  
##   GBTImage.image  
##   GBTbeam.psf containing the GBT beam normalized to a peak of 1
## Both of these image cubes must contain the same 'restoringbeam' information, 
## so it's probably easiest to just copy GBTImage.image to GBTbeam.psf and then
## fill in the pixel values from your existing python arrays containing the GBT beams.
#do_reconstruct();
