import numpy as np
import matplotlib.pyplot as plt
import os

#get the data from the PSF.
def getdata(imagename = '', extension = ''):
	ia.open(imagename + extension);
	pixdata = ia.getchunk();
	ia.close();
	return pixdata;


# Calculate the PSFs with the standard formula.
def CalcPSF(pixdata, nterms, freqlist):
	psf_at_spectral_term = np.zeros(pixdata[:,:,0,0].shape);
	psf_array = psf_at_spectral_term;
	num_psfs = 2*nterms - 1;
	for i in range(0, num_psfs):
		if(i < num_psfs-1):
			psf_array = np.dstack((psf_array, psf_at_spectral_term)); # Create a data structure to hold all PSFs.
		psf_at_tt_i = np.zeros(pixdata[:,:,0,1].shape);	# PSF as a Taylor coefficient for Exponent i
		for freq in freqlist:
			scalefactor = ((freq - 1.5)/1.5)**i ; # calculate the exponent 
			index = freqlist.index(freq);
			temp = pixdata[:,:,0,index]*scalefactor; # store the PSF at a given freq channel in an array temp.
			psf_at_tt_i += temp;	# Add all of these temp arrays and generate the Taylor multiterm PSFs.
		psf_array[:,:,i] = psf_at_tt_i; # dump this data into the data structure.
	return psf_array;	

# Just like above, calculate the Residuals using the standard formula.
def CalcResiduals(pixdata, nterms, freqlist):
	pass
# Write the data collected in this structure into separate CASA-readable files.
def write_to_casaimage(data, imagename = ''):
	numpsfs = data.shape[2]; # get the total number of psfs.
	for i in range(0, numpsfs):
		ia.open(imagename + str(i) +'.psf');
		ia.setrestoringbeam(remove = True);
		pixeldata = ia.getchunk();
		pixeldata[:,:,0,0] = data[:,:,i];
		ia.putchunk(pixeldata);
		ia.close();

pix = getdata('psf_residual_creator', '.psf');
#psfs = CalcPSF(pix, 2, [1.0, 1.5, 2.0]);
#write_to_casaimage(psfs, imagename = 'MTPSF');
CalcResiduals(pix, 10, [1.0, 1.5, 2.0]);
