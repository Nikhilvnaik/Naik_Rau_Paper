import numpy as np
import matplotlib.pyplot as plt
import os

def CalcGBTResidual(modelname = '', sdimage = ''):
    #(1) Smooth model cube by SD beams (per chan)
    #(2) Calculate residual SDcube :  sdresidual = sdimage - smoothed(modelcube)
	os.system('rm -rf SmoothedModel_chan*');
	ia.open(sdimage + '.residual');
	numplanes = ia.getchunk().shape[3]; # Number of sub-images to make.
	data_gbtimage = ia.getchunk();      # Getting the data from the file.
	ia.close();

	for i in range(0, numplanes):
		ia.close();
	# Create multiple subimages to first pull out the individual frequencies from the model image	
		imsubimage(imagename = modelname + '.model', outfile = 'ModelImage_chan_' + str(i) + '.temp', chans= str(i));
	# Open the SD image and pull out its restoring beam - needed  for feathering later on
		ia.open(sdimage + '.image');
		beam_at_chan_i = ia.restoringbeam(channel = i);
		print beam_at_chan_i
		ia.close();
	# Smooth the model with the GBT primary beam.

		ia.open('ModelImage_chan_' + str(i) + '.temp')
		smoothedim = ia.convolve2d(type='gaussian', outfile='SmoothedModel_chan' + str(i) + '.model' , major=beam_at_chan_i['major'], minor=beam_at_chan_i['minor'],pa = beam_at_chan_i['positionangle']);
		
	#Get the data from the single dish image residual and the smoothed model, subtract and place the result in the residual file.
		data_smoothed_model = ia.getchunk();
		ia.close();
		smoothedim.close();
		residual_gbt_data_freq_i = data_gbtimage[:,:,0,i] - data_smoothed_model[:,:,0,0];
		#:plt.imshow(residual_gbt_data_freq_i);
		#plt.colorbar(orientation = 'vertical')
		#raw_input("Press Return");	
		os.system('rm -rf ModelImage_chan_' + str(i) + '.temp');
		data_gbtimage[:,:,0,i] = residual_gbt_data_freq_i;

# Write this thing out to a CASA image format, replacing the old GBT residual file. 
	ia.open(sdimage + '.residual');
	ia.putchunk(data_gbtimage);
	ia.close();

CalcGBTResidual(modelname = 'Try', sdimage = 'GBTImage');
