import numpy as np 
import matplotlib.pyplot as plt 
from scipy import signal 
import scipy
import os
## iatool = casac.image()

powerpattern_1D = np.loadtxt('GBTpowerpattern.txt', delimiter = ',', comments = '#'); # Read the data as a 1D array first
Npixels = np.sqrt(powerpattern_1D.shape); #Calculate the number of pixels (It is also there in the file header.)
powerpattern = powerpattern_1D.reshape(Npixels, Npixels); #Convert it into a square matrix of Npixels * Npixels size.

# Get the remaining info about the power pattern, such as FOV and No. of pixels.
with open('GBTpowerpattern.txt', 'r') as f : 
	header = f.readline().strip(); 

fov_u = float(header[6:19]); # Get the FOV in RA from header
fov_v = float(header[20:]);  # Get the FOV in DEC from header

# Plot the power pattern that you've read from the file.
plt.subplot(121);
plt.imshow(powerpattern, extent = [-fov_u/2.0, +fov_u/2.0, -fov_v/2.0, fov_v/2.0]);
plt.xlabel('RA in arcmin from centre.');
plt.ylabel('DEC in arcmin from centre.');
plt.title('GBT power pattern');
#plt.colorbar(orientation = 'vertical');
#plt.show();	

# Open the mysky.true.im image file and create the image from the power pattern.

picture = ia.open("mysky.true.im");
if(picture == False):
	print("Error in opening picture file!");
picture_data = ia.getchunk();
picture_at_f1 = picture_data[:,:,0,1]; 
FFTshifted_picture_at_f1 = scipy.fftpack.fft2(picture_at_f1);
FFT_picture_f1 = scipy.fftpack.fft(FFTshifted_picture_at_f1);
FFTshifted_powerpattern = scipy.fftpack.fft2(powerpattern);
SkyImage = signal.convolve2d(picture_at_f1, powerpattern, mode = 'same');
SkyImage = SkyImage/np.amax(SkyImage);
plt.subplot(122);
plt.imshow(SkyImage.T, extent = [-fov_u/2.0, +fov_u/2.0, -fov_v/2.0, fov_v/2.0]);
plt.xlabel('RA in arcmin from centre.');
plt.ylabel('DEC in arcmin from centre.');
plt.title('Sky Image as seen by GBT');
plt.colorbar(orientation = 'vertical');
plt.show();

# Write the output pattern to a file for future programs to read.
try:
        os.system('rm -rf GBTImage.txt');
except:
        print('GBT Image file doesn\'t exist. Creating one...');

ImageOut = open('GBTImage.txt', 'a');
ImageOut.write('# ' + str(N) + ' ' + str(fov_u) + ' ' + str(fov_v) +'\n');
ImageOut.write('# ' + 'Npixels, FOV in RA, FOV in DEC in that order recorded above.\n');

# The actual writing part. In case it's tha last entry, omit the comma.
for i in range(0, SkyImage.shape[0]):
        for j in range(0, SkyImage.shape[1]):
                if(i == SkyImage.shape[0] -1 and j == SkyImage.shape[1] -1):
                        ImageOut.write(str(SkyImage[i][j]));
                else:
                        ImageOut.write(str(SkyImage[i][j]) + ',');

# Save and Close the file.
ImageOut.close();

