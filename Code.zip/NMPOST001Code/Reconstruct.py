## (1) Import the python application layer

from imagerhelpers.imager_base import PySynthesisImager
from imagerhelpers.input_parameters import ImagerParameters

sdgain = 25.0; # For feathering, set the single dish gain.
ia.close();
ib = iatool();

def do_reconstruct():

## (2) Set up Input Parameters 
##       - List all parameters that you need here
##       - Defaults will be assumed for unspecified parameters


    imname = 'Image_IFM'
    os.system('rm -rf Image_IFM.*')

    paramList = ImagerParameters(
        msname ='mysky.ms',
        datacolumn = 'corrected',
	field='',
        spw='',
        imagename=imname,
        imsize=256, 
        cell='16.0arcsec', 
        specmode='cube',
        gridder='standard',
        weighting='natural',
        niter=128,
        deconvolver='hogbom',
	nchan = -1
        )
    
#scales=[0,10,30],
## (3) Construct the PySynthesisImager object, with all input parameters

    imager = PySynthesisImager(params=paramList)
    
## (4) Initialize various modules. 

    imager.initializeImagers()           
    imager.initializeNormalizers()
    imager.setWeighting()
    imager.initializeDeconvolvers()
    imager.initializeIterationControl()

## (5) Make the initial images 
    imager.makePSF()
    imager.runMajorCycle()  # Make initial dirty / residual image

    feather_psf(imagename=imname)
    feather_residual(imagename=imname)

## (6) Make the initial clean mask
    imager.hasConverged()
    imager.updateMask()

## (7) Run the iteration loops
    while ( not imager.hasConverged() ):
        imager.runMinorCycle()
        imager.runMajorCycle()
	feather_residual(imagename=imname)
        imager.updateMask()


## (7) Finish up

    retrec=imager.getSummary();
    imager.restoreImages()
#imager.pbcorImages()

## (8) Close tools.

    imager.deleteTools()


####
#### Modify the PSF and Residual on disk by feathering in the GBT (SD) image and PB.
####
#==================================================================================================================================================
def feather_psf(imagename = 'Image_IFM'):
	os.system('rm -rf PSF_*_chan*.psf/');

	for i in range(0,3):	
#---------------------------------------------------------------------------------------------------------------------------------------------------
# Pull out channel-wise PSFs of IFM and single Dish, write them to disk. After feathering them, write out the hybrid PSF to the disk in a CASA image.
#---------------------------------------------------------------------------------------------------------------------------------------------------
		imsubimage(imagename = imagename + '.psf', outfile = 'PSF_IFM_chan' + str(i) + '.psf', chans = str(i));
		imsubimage(imagename = 'Image_SID.psf', outfile = 'PSF_SID_chan' + str(i) + '.psf', chans = str(i));
		feather(imagename = 'Feathered_psf_chan' + str(i) + '.psf', highres = 'PSF_IFM_chan' + str(i) + '.psf', lowres = 'PSF_SID_chan' + str(i) + '.psf', sdfactor = sdgain);
#------------------------------------------------------------------------------------------------------------------------------------------
    # (1) Use imsubimage to pull out each channel of SD_pb, imagename.psf
    # (2) Do the feathering (per channel) to make Feather_psf
    # (3) Copy the contents of Feather_psf (each plane) into imagename.psf
#-------------------------------------------------------------------------------------------------------------------------------------------
	write_to_casaimage(imagename = imagename, extension = '.psf');
	ia.close();	
	return;
#===========================================================================================================================================

#===========================================================================================================================================
def feather_residual(imagename=''):

 	os.system('rm -rf Image_SID_chan*.image'); # Remove all channel-wise images that were previously there.
	os.system('rm -rf Image_IFM_chan*.image'); # Both for the GBT as well as VLA images.
#------------------------------------------------------------------------------------------------------------------------------------------	
	# Restoring beam info has to be put in separately into the feather file, it isn't there. so copy the beam from PSF file.
	# Break both SD and IFM images into frequency-channel-wise subimages and feather them.
#------------------------------------------------------------------------------------------------------------------------------------------
	for i in range(0,3):
		imsubimage(imagename ='Image_SID.image', outfile = 'Image_SID_chan' + str(i) + '.image', chans = str(i));	
		imsubimage(imagename ='Image_IFM.residual', outfile = 'Image_IFM_chan' + str(i) + '.image', chans = str(i));		
	ia.open('Image_IFM.psf');
	for count in range(0,3): # This little trick had to be done to put in the beam info into the subimage. I guess mostly it's clear enough.
		beam_ifm = ia.restoringbeam(channel=count, polarization=0);
		ib.open('Image_IFM_chan' + str(count) + '.image');
		ib.setrestoringbeam(beam=beam_ifm);
		ib.close();
	ia.close();
#------------------------------------------------------------------------------------------------------------------------------------------
# Feather each one channel-by-channel and write to disk. Eventually I will remove the intermediate images and start writing only the final one.
#------------------------------------------------------------------------------------------------------------------------------------------
	for i in range(0,3):	
		feather(imagename = 'Feathered_img_chan' + str(i) + '.image', highres  = 'Image_IFM_chan' + str(i) + '.image', lowres = 'Image_SID_chan' + str(i) + '.image', sdfactor = sdgain);	
	# Now write everything into a composite image file.
	write_residual_to_casaimage(infiles = 'Feathered_img_chan', imagename= 'Image_IFM');
	return;
#===========================================================================================================================================

#===========================================================================================================================================
def write_to_casaimage(imagename = 'Image_IFM', extension = '.psf'):
	os.system('rm -rf '+ imagename + 'composite' + extension);
	os.system('cp -pr Image_SID.image ' + imagename + 'composite' + extension);
	ia.open(imagename + 'composite' + extension);
	pixeldata = ia.getchunk();
	for i in range(0,3):
		ib.open('Feathered_psf_chan' + str(i) + '.psf'); # only does the PSF as of now!!
		pixeldata_indiv_chunk = ib.getchunk(); # get chunk-wise pixel data.
		pixeldata_indiv_chan = pixeldata_indiv_chunk[:,:,0,0] # convert it into a numpy array to feed back in.
		pixeldata[:,:,0,i] = pixeldata_indiv_chan;
	ia.putchunk(pixeldata);
	ib.close();
	ia.close();
	return;
#===========================================================================================================================================
	
#===========================================================================================================================================
# Write the feathered image into the xyz.residual file.
#-------------------------------------------------------------------------------------------------------------------------------------------
def write_residual_to_casaimage(infiles = '', imagename = ''):
	ia.close(); #Close anything if it was open.
	ia.open(imagename + '.residual');
	pixel_data = ia.getchunk();
	ia.setrestoringbeam(remove = True);
	for i in range(0,3):
		ib.open(infiles + str(i) + '.image');
		beam = ib.restoringbeam(channel = 0, polarization = 0);
		pixel_data_residual = ib.getchunk(); # get the raw data from the single-channel images.
		ib.close();
		ia.setrestoringbeam(beam = beam, channel = i); # place the beam info in
		pixel_data[:,:,0,i] = pixel_data_residual[:,:,0,0];	# place the data in
	ia.putchunk(pixel_data); # put the data into the data structure.
	ia.close();	
#===========================================================================================================================================

## You will need  
##   GBTImage.image  
##   GBTbeam.psf containing the GBT beam normalized to a peak of 1
## Both of these image cubes must contain the same 'restoringbeam' information, 
## so it's probably easiest to just copy GBTImage.image to GBTbeam.psf and then
## fill in the pixel values from your existing python arrays containing the GBT beams.
do_reconstruct();
